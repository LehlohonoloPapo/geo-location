public class Jos_Tester {
    //Tester Class


    public static void main(String[] args) {
        Josephus_Survivor test1= new Josephus_Survivor(2,2);
        System.out.println();
        Josephus_Survivor test2= new Josephus_Survivor(15,4);
    }
}
