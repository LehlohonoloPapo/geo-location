public class FL_test {
    public static void main(String[] args) {


        String[] clubs = {"Liverpool (LVPL)", "Manchester City (MCTY)", "Leicester City (LCTY)", "Manchester United (MUTD)", "Chelsea (CLSE)", "Newcastle United(NCSU)", "Everton (EVTN)", "Psybergate FC (PSY)"};
        String[] matchResults = {"LVPL(2)-MCTY(2)", "MUTD(0)-EVTN(4)"};
        Football_League_Simulator test1 = new Football_League_Simulator(clubs, matchResults);
    }

}
